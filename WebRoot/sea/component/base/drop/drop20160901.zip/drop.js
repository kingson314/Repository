$.fn.drop = function(configs) {
	var defaults={
		offset:{
			left:0,
			top:0
		},
		onStart:function(startJq){
			
		},
		onEnd:function(startJq,endJq){
			
		}
	}
	var options=$.extend(true,{},defaults,configs); 
    var container = this;
    //初始化投放区域
    for(var i=0;i<$(this).length;i++){
    	var droper=$($(this)[i]);
    	if( droper.children().length ==0) {
            $("<div></div>").appendTo(droper).attr("class", "drop_block").css({"height":100});
        }
    }
    var startJq;
	$(container).delegate(".dropitem","mousedown",{},function(e) {
        if(e.which != 1 || window.SEA_DROP_ONLY) return; // 排除非左击和表单元素
        e.preventDefault(); // 阻止选中文本
 		startJq=$(this);
 		if(options.onStart){
    		options.onStart($(this));
    	}
        window.SEA_DROP_ONLY = true;
        var me = $(this);//.clone().insertBefore(self); // 点击选中块
        var meParent=me.parent();
        var pageX = e.pageX;
        var pageY = e.pageY;
        var width = me.width();
        var height = me.height();
        
        var left = me.offset().left;
        var top = me.offset().top;
        // 添加虚线框
        var sea_drop_holder = $("<div id='sea_drop_holder'></div>").insertBefore(me);
        sea_drop_holder.css({"border":"1px dashed #222", "height":me.outerHeight(true),"width":me.outerWidth(true)});
        // 保持原来的宽高
        me.css({"width":width, "height":height, "position":"absolute", opacity: 0.8, "z-index": 999, "left":left-options.offset.left, "top":top-options.offset.top});
        // 绑定mousemove事件
        $(document).mousemove(function(e) {
            e.preventDefault();
            // 移动选中块
            var l = left + e.pageX - pageX;
            var t = top + e.pageY - pageY;
            me.css({"left":l-options.offset.left, "top":t-options.offset.top});
            // 选中块的中心坐标
            var ml = l+width/2;
            var mt = t+height/2;
            // 遍历所有块的坐标
            $(container).children().not(me).not(sea_drop_holder).each(function(i) {
                var obj = $(this);
                var offset = obj.offset();
                var left1 = offset.left;
                var left2 = offset.left + obj.width();
                var top1 = offset.top;
                var top2 = offset.top + obj.height();
                // 移动虚线框
                if(left1 < ml && ml < left2 && top1 < mt && mt < top2) {
                    if(!obj.next("#sea_drop_holder").length) {
                        sea_drop_holder.insertAfter(this);
                    }else{
                        sea_drop_holder.insertBefore(this);
                    }
                    return;
                }
            });
        });
        // 绑定mouseup事件
        $(document).mouseup(function() {
            $(document).off('mouseup').off('mousemove');
            // 检查容器为空的情况
            $(container).each(function() {
                var obj = $(this).children();
                var len = obj.length;
                if(len == 1 && obj.is(me)) {
                    $("<div></div>").appendTo(this).attr("class", "drop_block").css({"height":me.height()});
                }else if(len == 2 && obj.is(".drop_block")){
                    $(this).children(".drop_block").remove();
                }
            });
            
            if(options.onEnd){
        		options.onEnd(startJq,sea_drop_holder);
        	}
            // 拖拽回位，并删除虚线框
            var offset = sea_drop_holder.offset();
            me.animate({"left":offset.left, "top":offset.top}, 100, function(){
            	me.removeAttr("style");
                sea_drop_holder.replaceWith(me);
                sea_drop_holder.height(me.height());
                if(meParent.is(me.parent())==true){
           		  //sea_drop_holder.remove();
           		  //me.remove();
                }
                window.SEA_DROP_ONLY = null;
            });
        });
    });
}